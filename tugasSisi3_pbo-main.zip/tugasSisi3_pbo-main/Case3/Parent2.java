/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Case3;

/**
 *
 * @author akmal
 */
// Kode setelah error diatasi

public class Parent2 {
    public Parent2 (){
    // kosong    
    }
}
