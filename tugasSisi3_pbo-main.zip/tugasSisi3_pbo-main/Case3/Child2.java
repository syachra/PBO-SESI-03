/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Case3;

/**
 *
 * @author akmal
 */
public class Child2 extends Parent2 {
    int x;
    
    // Konstruktor kelas Child2
    public Child2() {
        x = 5;
    }
}
