package Case2;

/**
 *
 * @author akmal
 */
// Kode program setelah error diatasi

public class Pegawai {
    private String nama;
    public double gaji;
    
    // Getter untuk variabel nama
    public String getNama() {
        return nama;
    }
    
    // Setter untuk variabel nama
    public void setNama(String nama) {
        this.nama = nama;
    }
}