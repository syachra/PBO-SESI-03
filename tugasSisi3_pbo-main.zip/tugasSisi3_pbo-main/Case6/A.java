package Case6;

/**
 *
 * @author akmal
 */
class A {
    String var_a = "Variabel A";
    String var_b = "Variabel B";
    String var_c = "Variabel C";
    String var_d = "Variabel D";
    
    A(){
        System.out.println("Konstruktor A dijalankan");
    }
}
